<div style='page-break-after: always; break-after: page;'></div>
# PART II

# The Way of Change 

###### In interpretation of the tholonic model in the style of the I Ching

## Coming Soon&hellip;

# The End

