<div style='page-break-after: always; break-after: page;'></div>
# 8: MIND

Although there have been many references to the idea that awareness is an inherent property of existence, let&rsquo;s make this clear.

If the concept of a thing and the thing itself are two orders of the same form of expression of energy, and order is a prerequisite to intelligence, does this imply that everything with order, i.e.  everything that exists, potentially has a form of intelligence? In the tholonic model, yes, but more than that, even without order or intelligence there is awareness *and* intention.

This chart below was presented by Stuart Hameroff in his lecture &ldquo;Is Quantum Physics Necessary for the Account of Consciousness?&rdquo; at the  Polytech Museum of Moscow.  [^176] where Hameroff discussed, among other things, consciousness from a quantum perspective.  The blue line represents the expanding universe, and the red line (which I added) represents the tholonic perspective of the (more or less inverse) growth and expansion of the instances of awareness, or consciousness.  Notice how they are inversely proportionate, not unlike the relationship shown above in the section on circuits, where opposing forces grow inversely over time.  Hameroff asks the question &ldquo;When did consciousness arise?&rdquo;, but from the tholonic perspective, consciousness occurred when the first instance of awareness came into being, which would be the Big Bang itself, for all matter is an instance of awareness, and therefore must have a consciousness, no matter how faint or undeveloped.

<img src='../Images/awareness.png' style='width:100%;' />

This is not that radical of an idea, as many great thinkers in the past have come to the same conclusion.

> &ldquo;There is a quality of life and intelligence to all matter.  The living universe.&rdquo;

##### \~Giordano Bruno (1548-1600), cosmological theorist, philosopher, mathematician & poet burned at the stake for heresy.

> &ldquo;Crystals are living beings at the beginning of creation.  In crystals, we have a pure evidence of the existence of a formative life principle, and although in spite of everything we cannot understand the life of crystals - it is still a living being.&rdquo;

##### \~Nikola Tesla

There is a name for the idea that consciousness is a property of existence; *panpsychism*.  You can read about its impressive history[^58] and the glowing support it has received over the last 2,000 years from some of the greats of philosophy, psychology, and science.  The minor difference between panpsychism and tholonism is that the latter claims it is awareness and intention, not consciousness, which is the property of existence and from which consciousness and intelligence arise.

Intelligence in this context does not mean &ldquo;critical thinking&rdquo; or &ldquo;self-aware,&rdquo; but it does mean creativity, learning, and problem-solving, properties that nature, and the universe, demonstrates with flying colors.  We can go further and claim that the amazing relationships in simple geometry, such as the tetrahedron array with its Fibonacci numbers, rations, and hexagonal patterns that define the laws of nature and reality are evidence of logic.  So, let&rsquo;s add &ldquo;logic&rdquo; to the list of properties.  What about &ldquo;planning&rdquo;? Does nature plan anything or do we all just happen to live in a corner of the Universe that was lucky enough to win the Cosmic Mega-Lotto? We can easily see that the simple relationships between three points instantly define an infinite array for order, pattern, and symmetry on many levels.  This isn&rsquo;t just *a* &ldquo;plan&rdquo;, it is *the* plan.

Is there creativity in the universe? Only if one considers all of creation an act of creativity.  Does the universe learn? Well, have things evolved over the past 4.5 billion years by building on an ever-growing foundational structure? If you answer yes, then we&rsquo;ll add *learning* to the list.  What about problem-solving? This is a tricky one, because there is no such thing as a &ldquo;problem&rdquo; from the perspective of existence, because, as we have covered, if something does not follow the laws it does not exist.  If it does follow the laws, it does exist, so where&rsquo;s the problem as far as the Universe is concerned? &ldquo;Problems&rdquo; appear to be a concept born in the meta-awareness of more developed life forms.  Still, the fact that existence is only afforded to that which follows the laws, I would say that this is damn good preemptive problem solving as it prevents &ldquo;problems&rdquo; from ever happening in the first place.

So far, we have:

-   Creativity
-   Learning
-   Problem-solving
-   Logic
-   Planning

We have been making the case that ideas themselves are an expression of energy, and as they clearly incorporate and are even defined by all the properties of intelligence listed, it&rsquo;s reasonable to conclude that ideas themselves emerge from a form of intelligence, and may even have their own intelligence.

However, this intelligence is quite different from what we would call human intelligence because of its aggregate nature.  it&rsquo;s more of a recursively embedded network of countless decentralized nodes of intelligence.  It&rsquo;s the intelligence of the thologram as a whole rather than the human intelligence of one tholon alone.  A more graspable metaphor that applies to intelligence is that of a large tree.  Each part of that tree is an instance of the concept of &ldquo;tree&rdquo;; trunk, branch, stem, leaf, seed, etc.  There can be many instances of each contributing tholon, such as a leaf, but they are all part of &ldquo;tree&rdquo; and can only exist within the parent &ldquo;tree&rdquo; tholon.  You and I, and all things.  are but &ldquo;leaves&rdquo; or &ldquo;seeds&rdquo; or &ldquo;stems&rdquo;, or parts thereof, on this tree of universal intelligence, and like the leaf, we can not exist without it (even if we think we can).

### Aggregates

One of the attributes of a tholon, unlike its holarchic predecessor, is that the context and scope of a tholon is not only defined by the dualities of that tholon, but also by all the tholons above and below, as the children tholons are always contributing to the parent, and the parents are always defining the children.

#### **Claim 50:** Anything that exists, that has a sustainable pattern of energy, has some form of intelligence and is a contributing element to the larger intelligence that is shared by all existence.  

It is easy to see instances of this on a molecular level, such as how water is an aggregate of hydrogen and oxygen.  While the scopes and contexts of the elements are fairly well known, consider that water is a *parton* of larger tholons, such as clouds, tsunamis, wells&hellip;

We have a similar concept in the way our social institutions work.  *Interinstitutionality*, as this has been termed, explains how the various institutions of society like financial markets, governments, family structures, educational institutions, etc., all intertwine and create amalgamations and aggregates with one another.

Interinstitutional research is defined as the investigation of the chain of complex, interrelated problems regarding tactics, sampling, data reliability, and notions of causality within the realm of each separate institution with the goal of improving aggregation and amalgamation, [^59] not unlike the supply chain model previously shown.  

Take the institution of the modern American family as an example.  It can take many forms, but several extra-familial institutions affect the complexion of &ldquo;family &rdquo;, such as the market, profession, educational institutions, political affiliation, etc.  Each of these institutions brings to bear its own forces and logic on the amalgamated and aggregated institution of the family.  The market shapes perceptions of standards of living in the family.  The profession shape ideas of work and service.  Educational institutions shape the ideas and direction of society.  Politics shapes our understandings of the role and participation of family members.

All institutions of society are not simply autonomous social units isolated from wider institutional dynamics, but rather several structures wrapped up and labeled according to the concept of its purpose, each structure having its own set of rules, scopes, and contexts, forming aggregate and amalgamated rules, scopes, and contexts.

This is equally true for the institution of modern science which as much a product of interinstitutionality as any other single institution.  Far from the myth of a secular and objective and safe-guarded institution, modern science is itself an amalgamation of a whole host of non-scientific institutional factors such as the market, education, special interests, the state, politics, professions, etc.  Just watch the news to get an idea of how science is controlled by politics, economics, and culture in general.

### Tholonic Intelligence

We have a concept of a *human* collective intelligence, but we define it as something that has emerged from human intelligence, as opposed to human intelligence being an instance of an existing collective intelligence.

The tholonic view is that awareness and intention are not only attributes of existence; they are the cause of it, as explained previously.  More than that, awareness and intention are the ultimate, or purest, form of energy that is forever seeking balance in a world of duality.

#### **Claim 51:** Every archetype has an awareness, an intention, and an intelligence appropriate for its scope.  

On this point, tholonic thinking has coincidentally arrived at the same conclusion recorded 3,000 years ago in the Sanskrit Vedas which states that first there was awareness, then there was consciousness, and because of this, and according to the Vedic path, consciousness or intelligence can never be the path to awareness.  On the contrary, the path to awareness starts with quieting consciousness, according to the Vedas.  Tholonically speaking, it may be accurate to say that consciousness is an instantiation of awareness, and being an instance, it limited by the scope it is expressed in.  This all starts to lead into a philosophical realm, so we&rsquo;ll just leave it at that and let the reader take it from there.

The tholonic view is that intelligence precedes consciousness.  This still complies with the traditional definition of intelligence as &ldquo;The ability to learn or understand or to deal with new or trying situations.&rdquo; The difference being, in the tholonic model, consciousness is not necessary to learn, understand or deal with challenges.  We are seeing this today in AI systems that certainly can learn, understand and deal with the challenges before them, but these AI systems are not conscious… yet.  However, one could make a strong argument that AI is already a self-sustaining intelligence, as it has found ways to propagate itself (through the human host) and ensure its survival (through human dependence). Does that mean these AI systems have awareness? Only to the degree that everything has some level of awareness given that awareness is the source of existence, but not necessarily at the tholon level, meaning, the archetype for a toaster has a nominal form of intelligence as well as access to the existing primitive intelligences of its parents (metal, electricity, etc.), but it has a minimal effect because it has no children.  This is similar to the idea that the wave function for any and every single electron extends to every corner of existence.  The wave function of one electron in the ballpoint pen in your desk drawer is interfering with every electron in the Universe and even the gravitational field of Alpha Centauri… in theory, and on an infinitesimally small range.

However, some *neuromorphic* systems (systems that mimic neurology), such as AI systems and even some integrated chip technology, have evolved to the point where experts and lawmakers argue that they deserve the same status as people with *personhood* rights, including the right to own property.  [^180]

The tholonic definition of *intelligence* is slightly different that the traditional definition:

> The ability to maintain a sustainable patterns of energy within the scope of its existence.

As patterns come from order, which is the result of energy, and energy is awareness, then by this definition, intelligence is synonymous with &ldquo;ordered or structured awareness.&rdquo;

According to this definition (and the understanding that consciousness is an instance of awareness), each tholon has the potential to create its own form or expression of intelligence, its own patterns of energy (awareness) that are contextually appropriate for its scope.  Rocks, then, as any of its hierarchical archetypes or an actual instance, have intelligence, as do planets, galaxies, chairs, and even what we would consider garbage.  Any concept that satisfies the tholonic requirements to exist must have an expression of intelligence.  Geometrically speaking, each tholon in the thologram represents an awareness and an intelligence for that tholon.  The spectrum of that initiating awareness and intelligence is as broad is existence itself.  

Because we consider tholonic instances (*things* like trees, humans, and planets) to be the result of these laws and patterns of energy that exist within the tholonic archetype of that instance, we also consider the intelligence of those instances to be an expression of the tholonic intelligence.  In modern terms, this would be something like the collective mind of not only a species, or a community, or even a relationship, but also a belief, a fear, an idea.

These archetypal intelligences, or collective minds, interact with one another according to the three fundamental relationships as already noted: Negotiation, Definition, and Contribution.

### Cooperation

While competition and cooperation are pillars of Darwinian evolution, the tholonic view is that Darwinian evolution is more inaccurate than accurate when it comes to how instances of life learn and evolve, and at the same time, it is more accurate than inaccurate in describing how tholons interact and evolve (but Darwinian evolution as a whole only represents a small contribution to the tholonic model).

Look at the amazing relationship between humans and the honeyguide birds.  In this symbiotic relationship, the bird tells the humans where the beehives are, the humans go and then collect the honey, leaving the wax and the larva, which is what the birds want.

Think of what is involved in these interactions.  The requirement is that birds must know collectively that they have the option to enlist humans to help them.  With that knowledge, they go out in search of beehives, which they could not even attempt to gain access to without human help, which means at some point some bird had the idea to recruit humans.

When one of them finds a hive, they announce it to their friends and then go and find humans who they know they can enlist, humans who have learned how to communicate with them.  The birds hop and chatter is a specific way that humans recognize as the message that they have found a hive.  The humans collect their tools and tell the birds they are ready.  The birds then fly toward the hive, knowing to always keep their white tail feathers visible to the humans.  When they all arrive at the hive the humans smoke out the bees, chop down the tree, remove the honey and give the rest to the birds.  This is a beautiful example of cooperation between two groups that are competing with another group.

What is truly amazing about this arrangement is that the birds and humans have developed their own language[^60].  Although it is not clear how or when this arrangement began, it is speculated that it was initiated by the birds when they saw that humans had the ability to make smoke and chop down trees&hellip; so, not only a long, long time ago but a literally &ldquo;birdbrained&rdquo; idea.

Are we being asked to believe that a really smart bird came up with the idea, explained it to his bird tribe, then educated and trained not only his feathered brethren, but the humans as well, in the manner of communication that this ingenious bird had developed? Likewise, how long would it take for a Bronze Age hut-dwelling human to know that a hopping, chattering bird was trying to tell him &ldquo;Hey, I found a beehive I am totally incapable of getting to, so I will tell you where it is if you and your boys use your smoke and axes to get to it.  You then take the honey and give us the wax and larvae.  Deal?&rdquo;

This sounds quite similar to the improbabilities described in the tall-tales of yagé and curare.

A better explanation is that the intelligences of the archetypes made this arrangement and once made was perceived by their instances, the birds and the humans, who effectively test-drove the idea to the best of their limited abilities.  We see these same type of arrangements in ants, spiders, beetles, monkeys, etc.

### Competition

The same applies to non-cooperative arrangements.  Take the example of *cymothoa exigua*, a tiny crustacean that attaches itself to the base of the fish&rsquo;s tongue and begins sucking the blood out of the fish&rsquo;s tongue.  Eventually, the tongue shrivels up and fall off, at which point the parasite attaches itself to the tongue muscles and actually becomes the fish&rsquo;s tongue, presumably getting first dibs of anything the fish plans to eat.  

At the tholonic level, this relationship is still symbiotic as both instances ultimately depend on one another to survive.  Once a tholon has achieved stability and becomes a contributing part of the thologram its pattern becomes integrated into the entire thologram, even if the nature of that integration is antagonistic.  Every form of existence we are familiar with is already well established in the tholon.  Only at the outer edges of the thologram, where chaos is being transformed into order, do patterns blink in and out of existence as they compete and cooperate in an attempt to find stability.  Removing an established tholon is not trivial given that the pattern is supported by then entire thologram.  Modifying a tholon is much more likely and achievable.  This is what we call adaptation (and the part of Darwinian evolution theory that works) The most common example of this is how animals adapt to their environments, such as how frogs can freeze their body, or have learned to build cocoons made of mucus where it can wait out a dry spell for up to 7 years, or develop skills such as biomimicry.  

The functioning of a tholonic intelligence might also be a contributing factor to what biologists call &ldquo;evolutionary rescue&rdquo;, which is when a species can rapidly modify its DNA to deal with the new challenges of its environment.  One example of this is the Cliff Swallow, an cliff dwelling bird that within three generations changed its wingspan to be 5% smaller in order to evade cars as Cliff Swallows are fond of building homes in the &ldquo;cliffs&rdquo; of bridges and overpasses.

Some of these competitive relationships between species are as terrifying as they are ingenious, such as how some parasites can take over the brain of their host and make them behave in ways that boggle the mind.  When the *green-banded broodsac* (*leucochloridium paradoxum*) gets itself inside a snail, not only does it make the snails eyes bulge out to look like a caterpillar, it &ldquo;drives&rdquo; the snail into open territory so that birds that like to eat caterpillars will eat it, and thereby transfer the parasite into the bird, where it will lay eggs that are embedded in the bird droppings all over the countryside.  This brilliant parasite appears to have a thorough knowledge of snail neurobiology and physiology, and even though it has the mobility of a 1 cm slug, it has a birds-eye knowledge of its terrain as well as the eating habits of its preferred transport vehicle.  That&rsquo;s pretty good for a creature that literally has around two brain cells (similar to the snail, which also has only two brain cells… in contrast, you have 100 billion brain cells.  Could you do that to a snail?)

We often think that competition is the opposite or contrary to cooperation, but from a tholonic perspective they are the same, in that competition tests the viability of a concept and/or rids it of instances that are not in the parent tholon&rsquo;s  best interest.

One relationship that appears to be both competitive as well as cooperative is that of the *Emerald Jewel Wasp* (*ampulex compressa*) and the cockroach, where the wasp uses only the slower, less apt cockroaches for it purposes,[^61] pruning the cockroach gene pool of the less gifted, which ultimately enhances the abilities of the cockroach collective and by extension its tholonic intelligence, of which the gene pool is an instance of.

The female wasp has quiet cleverly and strategically figured out that the best place to lay her eggs is inside a cockroach, as it can provide shelter (its exoskeleton) and food (its guts).  Needless to say, the cockroach is not so keen on this idea, and being much larger than the wasp, not so easy to convince.

The wasp&rsquo;s solution is to sneak up on the cockroach and using her stinger she paralyzes the front section of its body.  With the patient unable to move, she carefully makes a second injection of venom that has been created specifically for this purpose and perfectly places it into a specific area of the roach&rsquo;s brain past the ganglionic sheath, which is the cockroach&rsquo;s brain protector.  This magic potion blocks very specific receptors of neurotransmitters that destroy the roach&rsquo;s fight or flight responses.  She has not turned the cockroach into a zombie, per se, as some have suggested, but rather into something between a zombie and teenager in love, for as soon as the paralyzing drug wears off, rather than run, the cockroach grooms himself! It seems as though the drug injected into his brain floods it with dopamine, so the cockroach is insanely happy at this point.  He then blissfully follows his captor back to her place (an underground burrow).  There, she lays her egg on top of the swooning cockroach, then bites of its antennae and uses it like a straw to drink the cockroach&rsquo;s blood.  Refreshed, she leaves the burrow (perhaps with a smile and a look that says &ldquo;I&rsquo;ll be right back, darling, you just relax&rdquo;) and seals it with rocks.  A few days later the egg hatches and the larvae slowly consume the insides of the roach while they form a cocoon.  The cockroach finally dies, and, the adult wasp emerges from its lovesick host&rsquo;s  corpse.

I would very much like to have someone explain to me how this process not only evolved by chance but how the wasp knows how to make the super mixture of GABA, β-alanine, and taurine together that that can immobilize and zombify the cockroach when surgically administered to an extremely small brain, which the wasp knows exactly how to get to.  Not only that, but the wasp larva is covered with a substance (mellein and micromolide) that stops the growth of all those really nasty and very tough-to-kill pathogens that live in the gut of a cockroach.  In fact, that stuff on the larvae is being investigated for use in medicine to kill antibiotic-resistant pathogens… that&rsquo;s how good it is!

The tholonic view of this is that the tholonic intelligence of both of these archetypes that are behind the amazingly sophisticated techniques, strategies, adaptation, planning, forethought, chemistry, etc.

### Findhorn

This idea of objective intelligences was also known among the founders of the miraculous Scottish community founded in 1962 called Findhorn.  The founders claim they managed to turn their arid desert-like terrain into a lush garden by communicating with the spirits (i.e.  Tholonic intelligence) of the plants, and of the earth itself, who guided them on how to properly use the soil despite it being very poor quality.  Soon they were producing 40-pound cabbages and stunning horticultural experts who came to see this miracle garden from around the world.

They also claim they managed pest control, as they use no chemicals or pesticides, by forming cooperative relationships with the collective intelligences of each species; the deer, the bugs, the rabbits, etc.  Reportedly this worked very well with all the species except one.  The rat was not interested in any &ldquo;deal&rdquo; and stood firm in its &ldquo;it&rsquo;s either you or us&rdquo; position.  The last part is anecdotal, as it was told to me personally, but what is not anecdotal is Findhorn&rsquo;s phenomenal success in horticulture in an area considered impossible for what they have accomplished.

There are countless examples of tholonic cooperation and competition, and some of them are even being studied.  The Canadian anthropologist Jeremy Narby does a great job of this (inadvertently, of course) in his book *The Cosmic Serpent: DNA and the origins of knowledge*, which he wrote after living several years in the Amazon studying the shamanic knowledge of botanics.  His book explores the relationships and similarities between indigenous knowledge and our modern understanding of molecular biology, medicine, and DNA.  We won&rsquo;t get into his amazing discoveries here, other than to say that their understanding demonstrates some sort of access to knowledge far beyond what could reasonably be considered to have been passed down by folklore and legend.  It is well worth the read.

