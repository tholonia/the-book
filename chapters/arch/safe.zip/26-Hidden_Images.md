<div style='page-break-after: always; break-after: page;'></div>
# G - Hidden Images

<img src='../Images/embedded-page.png' style='width:100%'>

*Credits, left to right, top to bottom.*

**[Equation]** by *Aphex Twin*. Image via Jarmo Niinisalo

**Windowlicker** by *Aphex Twin*. Image via Jarmo Niinisalo

**Continuum** by *Disasterpeace* (FEZ Soundtrack). Image via Black Coffee Spirit

**My Violent Heart** by *Nine Inch Nails*. Image via the nine inch nails wiki

**Beyond** by *Disasterpeace* (FEZ Soundtrack). Image via Black Coffee Spirit

**Transitions** by *DJ Sonix*. Photograph via guru3d forums

**Compass** by *Disasterpeace* (FEZ Soundtrack). Image via Black Coffee Spirit

**Stripes** by *sippenaken*. Image via sippenaken on YouTube. Image via sippenaken on YouTube

**Flow** by *Disasterpeace* (FEZ Soundtrack). Image via Black Coffee Spirit

**Compass** by *Disasterpeace* (FEZ Soundtrack). Image via Black Coffee Spirit

**Look** by *Venetian Snares*. Image via Jarmo Niinisal 

Complete images and more at https://twistedsifter.com/2013/01/hidden-images-embedded-into-songs-spectrographs/

