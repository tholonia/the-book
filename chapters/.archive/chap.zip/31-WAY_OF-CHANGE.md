<div style='page-break-after: always; break-after: page;'></div>
# The Way of Change 

###### An interpretation of the I-Ching, in the style and manner of the traditional I-Ching, using Tholonic concepts.

## Coming Soon&hellip;

# The End

